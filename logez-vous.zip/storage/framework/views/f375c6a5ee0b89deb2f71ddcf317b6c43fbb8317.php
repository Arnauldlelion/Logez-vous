
<?php $__env->startSection('title', 'Testimonials'); ?>

<?php $__env->startSection('content'); ?>
	
	<!-- start page title -->
	<div class="row">
		<div class="col-12">
			<div class="page-title-box">
				<div class="page-title-right">
					<ol class="breadcrumb m-0">
						<li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
						<li class="breadcrumb-item active">Testimonials</li>
					</ol>
				</div>
				<h4 class="page-title">Testimonials</h4>
			</div>
		</div>
	</div>
	<!-- end page title -->
	
	<div class="">
		<div class="card card-body">
			<div class="text-right mb-3">
				<a href="<?php echo e(route('admins.testimonials.create')); ?>" class="btn btn-secondary">Add Testimony</a>
			</div>
			<div class="table-responsive">
				<table class="table table-bordered table-sm">
					<thead>
					<tr>
						<th>S/N</th>
						<th>Name</th>
						<th>Title</th>
						<th>Video</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($loop->index + 1); ?></td>
							<td>
								<div class="d-flex align-items-center">
									<img src="<?php echo e($testimony->getImageUrl()); ?>"
									     class="img-thumbnail"
									     style="width: 2.75rem; max-height: 2.75rem;">
									<div class="pl-2">
										<p class="mb-0"><?php echo e($testimony->name); ?></p>
									</div>
								</div>
							</td>
							<td><?php echo e($testimony->title); ?></td>
							<td><?php echo e($testimony->video); ?></td>
							<td>
								<div class="btn-group">
									<a href="<?php echo e(route('admins.testimonials.edit', $testimony->id)); ?>"
									   class="btn btn-secondary btn-sm"><i class="fa fa-edit"></i></a>
									<a href="#"
									   data-toggle="modal"
									   data-target="#deleteModal<?php echo e($testimony->id); ?>"
									   class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
								</div>
							</td>
						</tr>
						
						
						<?php if (isset($component)) { $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\DeleteModal::class, ['id' => $testimony->id,'url' => route('admins.testimonials.destroy', $testimony->id)]); ?>
<?php $component->withName('delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6)): ?>
<?php $component = $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6; ?>
<?php unset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6); ?>
<?php endif; ?>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td colspan="100%">No Records Found</td>
						</tr>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>