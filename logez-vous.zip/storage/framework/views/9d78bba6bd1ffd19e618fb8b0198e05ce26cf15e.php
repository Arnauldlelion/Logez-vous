<a href="/appartements/name" class="house-card h-100 shadow-lg">
    <?php if($showBanner): ?>
        <div class="img-container">
            <img src="/storage/images/premium.png" class="img-fluid premium" alt="<?php echo e(config('app.name')); ?>">
        </div>
    <?php endif; ?>
    <div class="card <?php echo e($showBorder ? 'card-border' : ''); ?>">
        <?php if($isSlider): ?>
            <div class="card-img-top">
                <?php echo $__env->make('components.card-carousel', [
                    'index' => $index,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php else: ?>
            <img src="/storage/images/room.jpeg" alt="Room" class="card-img-top">
        <?php endif; ?>
        <div class="card-body">
            <div class="num-text">toulon (83200)</div>
            <div class="price">8,000 XAF cc - 57.0 m<sup>2</sup></div>
            <div class="rooms">3 pièces * non meublé * 1er étage</div>
            <div class="published">Publié le 11 juillet 2023</div>
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/components/card.blade.php ENDPATH**/ ?>