<div class="house-card h-100 shadow-lg">
    <?php if($showBanner): ?>
        <div class="img-container">
            <img src="/storage/images/premium.png" class="img-fluid premium" alt="<?php echo e(config('app.name')); ?>">
        </div>
    <?php endif; ?>
    <div class="card <?php echo e($showBorder ? 'card-border' : ''); ?>">
        <?php if($isSlider): ?>
            <div class="card-img-top">
                <?php echo $__env->make('components.card-carousel', [
                    'index' => $index,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php else: ?>
            <img src="<?php echo e(asset('storage/' . $apartment->coverImage->url)); ?>" alt="Room" class="card-img-top">
        <?php endif; ?>
<div class="card-body">
    <div class="num-text"><?php echo e($apartment->property->location); ?> (83200)</div>
    <div class="price"><?php echo e($apartment->monthly_price); ?> XAF cc - 57.0 m<sup>2</sup></div>
    <div class="rooms"><?php echo e($apartment->number_of_appartnents); ?> * <?php echo e($apartment->furnished); ?> * <?php echo e($apartment->floor); ?></div>
    <!--<div class="published">Publié le 11 juillet 2023</div>-->
</div>
</div>
</div>

<?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/components/card.blade.php ENDPATH**/ ?>