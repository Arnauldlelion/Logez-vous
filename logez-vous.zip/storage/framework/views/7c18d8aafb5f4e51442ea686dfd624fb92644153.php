

<?php $__env->startSection('content'); ?>

    <div class="auth-fluid">
        <!--Auth fluid left content -->
        <div class=" auth-fluid-form-box">
            <div class="align-items-center d-flex h-100">
                <div class="container col-lg-10">
                    <div class="card-body">
                        <!-- title-->
                        <div class="d-flex align-items-center mb-5 mt-5">
                            <img src="<?php echo e(asset('storage/images/logos/devis.png')); ?>" alt="" height="64">
                            <h1 class="text-danger">Ajouter un bien</h1>
                        </div>

                        <!-- form -->
                        <form action="<?php echo e(route('landlord.property.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                                <label for="name" class="col-sm-2 col-form-label-sm">Nom du bien</label>
                                <div class="col-12 col-lg-7">
                                    <input
                                        class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        type="text" id="name" value="<?php echo e(old('name')); ?>" name="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                                <label for="appartmentType" class="col-sm-2 col-form-label-sm">Type d'Appartment</label>
                                <div class="col-12 col-lg-7">
                                    

                                    <?php $__empty_1 = true; $__currentLoopData = \App\Models\AppartmentType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apt_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="d-flex gap-3">
                                            <input type="checkbox" name="appartmentType[]" value=<?php echo e($apt_type->id); ?>

                                                id="">
                                            <label for=""><?php echo e($apt_type->name); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div>No Appartment type has been added. Please Contact the admin</div>
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['appartmentType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                                <label for="location" class="col-sm-2 col-form-label-sm">Emplacement</label>
                                <div class="col-12 col-lg-7">
                                    <input
                                        class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        type="text" id="location" value="<?php echo e(old('location')); ?>" name="location"
                                        placeholder="Douala,Bonanjo">
                                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="w-100 mb-5">
                                <div class="text-black float-start">
                                    <a href="<?php echo e(route('landlord.index')); ?>" class="text-secondary">
                                        <i class="mdi mdi-chevron-left text-secondary"></i>
                                        Back
                                    </a>
                                </div>
                                <button type="submit" class="btn btn-danger rounded-pill float-end">Ajouter</button>
                            </div>
                        </form>
                        <!-- end form-->
                    </div>

                </div> <!-- end .card-body -->
            </div> <!-- end .align-items-center.d-flex.h-100-->

        </div>
        <!-- end auth-fluid-form-box-->
    </div>
    <!-- end auth-fluid-->

    </div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/landlord/property/create.blade.php ENDPATH**/ ?>