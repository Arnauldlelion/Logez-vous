 <!-- Assuming you have a layout file -->

<?php $__env->startSection('content'); ?>
<div class="container mb-5" style="margin-top:8rem">
    <div class="shadow-lg bg-white p-3 p-lg-5">
<!-- recent-properties.blade.php -->
<h1>Recently Created Properties</h1>

<?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <img src="<?php echo e(asset($property->image)); ?>" alt="Property Image">
        <h2><?php echo e($property->town); ?></h2>
        <p>Quarter: <?php echo e($property->quarter); ?></p>
        <p>Monthly Price: <?php echo e($property->monthly_price); ?></p>
        <p>Size: <?php echo e($property->size); ?></p>
        <p>Pieces: <?php echo e($property->pieces); ?></p>
        <p>Description: <?php echo e($property->description); ?></p>
        <p>Furnished: <?php echo e($property->furnished ? 'Yes' : 'No'); ?></p>
        <p>Floor: <?php echo e($property->floor); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/recent-properties.blade.php ENDPATH**/ ?>