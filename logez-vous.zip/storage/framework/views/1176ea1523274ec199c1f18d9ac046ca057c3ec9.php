<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" sizes="16x16" type="image/png">
    
    <meta name="tcss" content="<?php echo e(asset('css/tiny.css')); ?>" />

    <title><?php echo $__env->yieldContent('title'); ?> | Admin Back-office | autocomplete</title>

     <!-- App css -->
    <link href="<?php echo e(asset('admin_assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('admin_assets/css/app.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('admin_assets/css/datatables.min.css')); ?>" rel="stylesheet"/>

    <!-- icons -->
    <link href="<?php echo e(asset('admin_assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css"/>

    <?php echo $__env->yieldContent('header-style'); ?>
    
    <style>
        .readmore {
            overflow: hidden;
        }
        
        label > em {
            color: #ff5555;
        }
    </style>
</head>
<body>
    <div id="wrapper">

         <!-- Topbar Start -->
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end Topbar -->


        <!-- ========== Left Sidebar Start ========== -->
        <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Left Sidebar End -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <?php echo $__env->make('admin.layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->yieldContent('content'); ?>

                </div> <!-- container -->

            </div> <!-- content -->

        </div>
    
    </div>

    <!-- Vendor js -->
    <script src="<?php echo e(asset('admin_assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/libs/readmore.min.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('admin_assets/js/app.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/4.5.6/tinymce.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/tinymce/4.5.6/jquery.tinymce.min.js"></script>
     <script src="<?php echo e(asset('admin_assets/libs/tinymce/js/tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/common.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/js/admin.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('footer_script'); ?>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>