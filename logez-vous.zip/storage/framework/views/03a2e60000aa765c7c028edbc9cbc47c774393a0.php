

<?php $__env->startSection('content'); ?>
    <form action="/register" method="post" style="padding-top: 10rem; padding-bottom: 10rem; position:relative; align-items:center; display:block; text=align: center">
        <?php echo csrf_field(); ?>
        <div>
            <input type="text" placeholder="name" name="name">
        </div>
        <div>
            <input type="text" placeholder="email" name="email">
        </div>
        <div>
            <input type="text" placeholder="phone" name="phone">
        </div>
        <div>
            <input type="text" placeholder="password" name="password">
        </div>
        <div>
            <input type="text" placeholder="confirm password" name="password_confirmation">
        </div>
        <div>
            <input type="checkbox" name="type"> I am a landlord
        </div>
        <div>
            <input type="checkbox" name="subscribed"> I subscribe to new properties
        </div>

        <button type="submit">Register</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/auth/register.blade.php ENDPATH**/ ?>