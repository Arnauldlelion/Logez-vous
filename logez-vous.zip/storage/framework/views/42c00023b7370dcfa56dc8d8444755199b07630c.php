<div class="card">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($property->type); ?></h2>
        <img src="<?php echo e($property->image); ?>" alt="Property Image">
        <p><?php echo e($property->description); ?></p>
        <p>Town: <?php echo e($property->town); ?></p>
        <p>Quarter: <?php echo e($property->quarter); ?></p>
        <p>Monthly Price: <?php echo e($property->monthly_price); ?></p>
        <p>Size: <?php echo e($property->size); ?></p>
        <p>Number of pieces: <?php echo e($property->pieces); ?></p>
        <p>Furnished: <?php echo e($property->furnished ? 'Yes' : 'No'); ?></p>
        <p>Floor: <?php echo e($property->floor); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/card-property.blade.php ENDPATH**/ ?>