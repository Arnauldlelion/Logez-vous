<div id="card-carousel-<?php echo e($index); ?>" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <?php $__currentLoopData = $apartment->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" data-bs-target="#card-carousel-<?php echo e($index); ?>"
                data-bs-slide-to="<?php echo e($key); ?>" class="<?php echo e($key === 0 ? 'active' : ''); ?>"
                aria-current="<?php echo e($key === 0 ? 'true' : 'false'); ?>"
                aria-label="Slide <?php echo e($key + 1); ?>"></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="carousel-inner">
        <?php $__currentLoopData = $apartment->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($key === 0 ? 'active' : ''); ?>">
                <img src="<?php echo e(asset('storage/' . $image->url)); ?>" class="d-block w-100" alt="Image">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#card-carousel-<?php echo e($index); ?>"
        data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#card-carousel-<?php echo e($index); ?>"
        data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/components/card-carousel.blade.php ENDPATH**/ ?>