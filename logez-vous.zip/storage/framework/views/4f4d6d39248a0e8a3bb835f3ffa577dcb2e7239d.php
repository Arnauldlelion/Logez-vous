

<?php $__env->startSection('content'); ?>
    <div>
        <div class="text-white">
            <a href="<?php echo e(route("landlord.index")); ?>" class="text-white">
                <i class="mdi mdi-chevron-left"></i>
                Properties
            </a>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card card-body">
                    <div class="p-4">
                        <h4 class="text-capitalize"><?php echo e($property->name); ?> Apartments - <?php echo e($property->location); ?></h4>
                    </div>
                    <div class="text-end p-2">
                        <a href="<?php echo e(route('landlord.apartments.create')); ?>" class="btn btn-secondary">Add New apartments</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm text-white">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Monthly Price</th>
                                    <th>Furnished</th>
                                    <th>Number of Apartments</th>
                                    <th>Floor Level</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($apartment->monthly_price); ?></td>
                                        <td><?php echo e($apartment->furnished); ?></td>
                                        <td><?php echo e($apartment->number_of_appartments); ?></td>
                                        <td><?php echo e($apartment->floor); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('landlord.apartments.edit', $apartment->id)); ?>"
                                                    style="height: fit-content;" class="btn btn-secondary btn-sm">
                                                    <i class="mdi mdi-pencil"></i></a>
                                                <a data-toggle="modal" data-target="#deleteModal<?php echo e($apartment->id); ?>"
                                                    href="#" style="height: fit-content;" class="btn btn-danger btn-sm"><i
                                                        class="mdi mdi-delete"></i></a>
                                                <div>
                                                    <a href="<?php echo e(route('landlord.apartments.show', $apartment->id)); ?>"
                                                        class="btn btn-secondary btn-sm ml-4">
                                                        <i class="mdi mdi-eye"></i> Pieces</a>
                                                    <br><br>
                                                    <a href="<?php echo e(route('landlord.apartments.showRapports', $apartment->id)); ?>"
                                                        class="btn btn-secondary btn-sm ml-4">
                                                        <i class="mdi mdi-eye"></i> Rapports de Gestion</a>
                                                    <br><br>
                                                    <a href="<?php echo e(route('landlord.apartments.showPayments', $apartment->id)); ?>"
                                                        class="btn btn-secondary btn-sm ml-4">
                                                        <i class="mdi mdi-eye"></i> Payments</a>
                                                </div>
                                            </div>

                                        </td>
                                        <?php if (isset($component)) { $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\DeleteModal::class, ['id' => $apartment->id,'url' => route('landlord.apartments.destroy', $apartment->id),'content' => 'Are you sure you want to delete this Apartment <strong>' .
                                            $apartment->id .
                                            '</strong>? This action is irreversible']); ?>
<?php $component->withName('delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6)): ?>
<?php $component = $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6; ?>
<?php unset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6); ?>
<?php endif; ?>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="100%">No Appartment Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/landlord/apartments/index.blade.php ENDPATH**/ ?>