<div class="left-side-menu">

    <div class="h-100" data-simplebar>

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <ul id="side-menu h-100">

                
                <li class="<?php echo e(Route::is('admins.dashboard') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.dashboard')); ?>">
                        <i data-feather="home"></i>
                        <span> Dashboard </span>
                    </a>
                </li>
                <li class="<?php echo e(Route::is('admins.profile') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.profile')); ?>">
                        <i data-feather="user"></i>
                        <span> Profile </span>
                    </a>
                </li>

                <li class="menu-title">App</li>
    
    
                
                <li class="<?php echo e(Route::is('admins.piece_types.*') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.piece_types.index')); ?>">
                        <i data-feather="layers"></i>
                        <span> Piece Types </span>
                    </a>
                </li>
                <li class="<?php echo e(Route::is('admins.apartment_types.*') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.apartment_types.index')); ?>">
                        <i data-feather="layout"></i>
                        <span> Apartment Types </span>
                    </a>
                </li>

                <li class="menu-title">Post</li>
    
    
                <li class="<?php echo e(Route::is('admins.testimonials.*') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.testimonials.index')); ?>">
                        <i data-feather="thumbs-up"></i>
                        <span> Testimonials </span>
                    </a>
                </li>
                <li class="<?php echo e(Route::is('admins.news.*') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.news.index')); ?>">
                        <i data-feather="book-open"></i>
                        <span> News </span>
                    </a>
                </li>
                <li class="<?php echo e(Route::is('admins.faqs.*') ? 'menuitem-active' : ''); ?>">
                    <a href="<?php echo e(route('admins.faqs.index')); ?>">
                        <i data-feather="help-circle"></i>
                        <span> FAQs </span>
                    </a>
                </li>
<br><br><br>
                <li>
                    <form method="POST" action="<?php echo e(route('admins.logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link btn btn-link">
                            <i data-feather="log-out"></i>
                        <span> Log Out </span>
                        </button>
                    </form>
                </li>
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>