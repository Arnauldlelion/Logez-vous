
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
     
     <!-- start page title -->
     <div class="row">
          <div class="col-12">
               <div class="page-title-box">
                    <div class="page-title-right">
                         <ol class="breadcrumb m-0">
                              <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                              <li class="breadcrumb-item active">Home</li>
                         </ol>
                    </div>
                    <h4 class="page-title">Dashboard</h4>
                    <div class="">
                         <div class="card card-body">
                              <div class="table-responsive">
                                   <table class="table table-bordered table-sm">
                                        <thead>
                                        <tr>
                                             <th>S/N</th>
                                             <th>Name</th>
                                             <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $landlords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $landlord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                             <tr>
                                                  <td><?php echo e($loop->index + 1); ?></td>
                                                  <td><?php echo e($landlord->name); ?></td>
                                                  <td>
                                                       <div class="btn-group">
                                                            <a href="#"
                                                               class="btn btn-secondary btn-sm"><i class="fa fa-eye"></i></a>
                                                            <a href="#"
                                                               data-toggle="modal"
                                                               data-target="#deleteModal<?php echo e($landlord->id); ?>"
                                                               class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                                       </div>
                                                  </td>
                                             </tr>
                                             
                                             
                                             
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <tr>
                                                  <td colspan="100%">No Records Found</td>
                                             </tr>
                                        <?php endif; ?>
                                        </tbody>
                                   </table>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </div>
     <!-- end page title -->
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>