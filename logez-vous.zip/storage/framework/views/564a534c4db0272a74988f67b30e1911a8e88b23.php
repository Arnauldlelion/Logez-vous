
<?php $__env->startSection('title', 'Piece Types'); ?>

<?php $__env->startSection('content'); ?>
	
	<!-- start page title -->
	<div class="row">
		<div class="col-12">
			<div class="page-title-box">
				<div class="page-title-right">
					<ol class="breadcrumb m-0">
						<li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
						<li class="breadcrumb-item active">Piece Types</li>
					</ol>
				</div>
				<h4 class="page-title">Piece Types</h4>
			</div>
		</div>
	</div>
	<!-- end page title -->
	
	<div class="row">
		<div class="col-md-8">
			<div class="card card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-sm">
						<thead>
						<tr>
							<th>S/N</th>
							<th>Category</th>
							<th>Action</th>
						</tr>
						</thead>
						<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $piece_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piece_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($loop->index + 1); ?></td>
								<td><?php echo e($piece_type->name); ?></td>
								<td>
									<div class="btn-group">
										<a href="<?php echo e(route('admins.piece_types.edit', $piece_type->id)); ?>"
										   class="btn btn-secondary btn-sm"><i class="fa fa-edit"></i></a>
										<a href="#"
										   data-toggle="modal"
										   data-target="#deleteModal<?php echo e($piece_type->id); ?>"
										   class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
									</div>
								</td>
							</tr>
							
							<?php if (isset($component)) { $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\DeleteModal::class, ['id' => $piece_type->id,'url' => route('admins.piece_types.destroy', $piece_type->id),'content' => 'Are you sure you want to delete this Piece type <strong>'.$piece_type->name.'</strong>? This action is irreversible']); ?>
<?php $component->withName('delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6)): ?>
<?php $component = $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6; ?>
<?php unset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6); ?>
<?php endif; ?>

							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="100%">No Records Found</td>
							</tr>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card card-body">
				<form action="<?php echo e(route('admins.piece_types.store')); ?>" method="POST" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					
					<div class="form-group">
						<label>Name <em>*</em></label>
						<input type="text"
						       class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
						       name="name"
						       placeholder="e.g. General"
						       value="<?php echo e(old('name')); ?>"/>
						<?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="text-right">
						<button type="submit" class="btn btn-secondary">Save</button>
					</div>
				
				</form>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/admin/piece_types/index.blade.php ENDPATH**/ ?>