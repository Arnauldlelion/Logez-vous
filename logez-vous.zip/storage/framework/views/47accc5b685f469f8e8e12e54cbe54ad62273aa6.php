

<?php $__env->startSection('content'); ?>
    <div>
        <div class="text-white">
            <a href="<?php echo e(route("landlord.property.show", session('new_prop_id'))); ?>" class="text-white">
                <i class="mdi mdi-chevron-left"></i>
                Appartments
            </a>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card card-body">
                    <div class="p-4">
                        <h4 class="text-capitalize"><?php echo e($apartment->property->name); ?> > Apartment <?php echo e($apartment->id); ?> >
                            Rapports De Gestion - <?php echo e($apartment->property->location); ?></h4>
                    </div>
                    <div class="text-end p-2">
                        <a href="<?php echo e(route('landlord.rapports.create')); ?>" class="btn btn-secondary">Add New Rapport De
                            Gestion</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm text-white">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Annee Construction</th>
                                    <th>Nombre des Locataire</th>
                                    <th>Duree du Locataire</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $rapports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rapport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($rapport->annee_construction->format('d-m-y')); ?></td>
                                        <td><?php echo e($rapport->nombreDeLocataire); ?></td>
                                        <td><?php echo e($rapport->dureeDuLocataire); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('landlord.rapports.edit', $rapport->id)); ?>"
                                                    class="btn btn-secondary btn-sm">
                                                    <i class="mdi mdi-pencil"></i></a>
                                                <a data-toggle="modal" data-target="#deleteModal<?php echo e($rapport->id); ?>"
                                                    href="#" class="btn btn-danger btn-sm"><i
                                                        class="mdi mdi-delete"></i></a>
                                            </div>
                                        </td>
                                        <?php if (isset($component)) { $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\DeleteModal::class, ['id' => $rapport->id,'url' => route('landlord.rapports.destroy', $rapport->id),'content' => 'Are you sure you want to delete this Rapport <strong>' .
                                            $rapport->id .
                                            '</strong>? This action is irreversible']); ?>
<?php $component->withName('delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6)): ?>
<?php $component = $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6; ?>
<?php unset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6); ?>
<?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="100%">No Rapport Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/landlord/rapports/index.blade.php ENDPATH**/ ?>