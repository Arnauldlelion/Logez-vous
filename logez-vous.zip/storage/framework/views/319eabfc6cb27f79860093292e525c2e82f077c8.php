

<?php $__env->startSection('content'); ?>
    <div class="auth-fluid">
        <!--Auth fluid left content -->
        <div class=" auth-fluid-form-box">
            <div class="align-items-center d-flex h-100">
                <div class="container col-lg-10">
                    <div class="card-body">
                        <!-- title-->
                        <div class="d-flex align-items-center my-5">
                            <img src="<?php echo e(asset('storage/images/logos/devis.png')); ?>" alt="" height="64">
                            <h1 class="text-danger">Payment</h1>
                        </div>

                        <!-- form -->
                        <form action="<?php echo e(route('landlord.payments.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>


                            <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                                <label for="prices" class="col-sm-2 col-form-label-sm">Price</label>
                                <div class="col-12 col-lg-7">
                                    <input
                                        class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['prices'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        type="text" id="prices" value="<?php echo e(old('prices')); ?>" name="prices"
                                        placeholder="70,000 XAF">
                                    <?php $__errorArgs = ['prices'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                                <label for="commission" class="col-sm-2 col-form-label-sm">Commision</label>
                                <div class="col-12 col-lg-7">
                                    <input
                                        class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        type="text" id="commission" 
                                        value="<?php echo e(old('commission')); ?>" name="commission"
                                        placeholder="5%">
                                    <?php $__errorArgs = ['commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="w-100 mb-5">
                                <div class="text-black float-start">
                                    <a href="<?php echo e(route('landlord.apartments.showPayments', session('new_apt_id'))); ?>" class="text-secondary">
                                        Back
                                    </a>
                                </div>
                                <button type="submit" class="btn btn-danger rounded-pill float-end">Ajouter</button>
                            </div>
                        </form>
                        <!-- end form-->
                    </div>

                </div> <!-- end .card-body -->
            </div> <!-- end .align-items-center.d-flex.h-100-->

        </div>
    </div>
    <!-- end auth-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/landlord/payments/create.blade.php ENDPATH**/ ?>