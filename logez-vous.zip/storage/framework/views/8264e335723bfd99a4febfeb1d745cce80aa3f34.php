


<?php $__env->startSection('content'); ?>

<div class="auth-fluid" >
    <!--Auth fluid left content -->
    <div class=" auth-fluid-form-box" >
        <div class="align-items-center d-flex h-100" >
            <div class="container col-lg-10">
            <div class="card-body">
                 <!-- title-->
                 <div class="d-flex align-items-center mb-5 mt-5">
                    <img src="<?php echo e(asset('storage/images/logos/devis.png')); ?>" alt="" height="64">
                    <h1 class="text-danger">Detail de votre appartment</h1>
                </div>

                 <!-- form -->
                 <form action="<?php echo e(route('landlord.apartments.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>


                    

                       

                      <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                          <div class="col-12 col-lg-7">
                            <label for="floor" class="col-sm-2 col-form-label-sm">Niveau</label>
                            <input class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                            id="floor"
                            value="<?php echo e(old('floor')); ?>"
                            name="floor"
                            placeholder="Idris">
                            <?php $__errorArgs = ['floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                         <div class="d-flex gap-5">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="furnished" id="flexRadioDefault2" value="Non meublé">
                                <label class="form-check-label" for="flexRadioDefault2">
                                    Non meublé
                                </label>
                              </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="furnished" id="flexRadioDefault1" value="Meublé">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Meublé
                                </label>
                              </div>
                         </div>
                         <?php $__errorArgs = ['furnished'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         <div class="col-12 col-lg-7">
                            <label for="monthly_price" class="col-sm-2 col-form-label-sm">Prix</label>
                            <input class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['monthly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                               id="monthly_price"
                               value="<?php echo e(old('monthly_price')); ?>"
                               name="monthly_price"
                               placeholder="50000frs/month">
                        <?php $__errorArgs = ['monthly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>


                      <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                          <div class="col-12 col-lg-7">
                            <label for="number_of_appartments" class=" col-form-label-sm">Nombre de pieces</label>
                            <input class="form-control rounded-pill form-control-sm <?php $__errorArgs = ['number_of_appartments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number"
                               id="number_of_appartments"
                               value="<?php echo e(old('number_of_appartments')); ?>"
                               name="number_of_appartments">
                        <?php $__errorArgs = ['number_of_appartments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>

                      <div class="form-group row mb-5 d-block d-lg-flex align-items-center gap-5">
                        <div class="col-12 col-lg-7">
                        <label for="description">Description <em>*</em></label>
                        <textarea class="form-control tiny-textarea <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                  rows="5"
                                  name="description"
                                  placeholder=""
                                  ><?php echo e(old('description')); ?></textarea>
    
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>

                      <div class="w-100 mb-5">
                        <div class="text-black float-start">
                            <a href="<?php echo e(route('landlord.property.show', session('new_prop_id'))); ?>" class="text-secondary">
                                Back
                            </a>
                        </div>
                        <button type="submit" class="btn btn-danger rounded-pill float-end">Ajouter</button>
                    </div>

                </form>
                <!-- end form-->
               </div>

            </div> <!-- end .card-body -->
        </div> <!-- end .align-items-center.d-flex.h-100-->
        
    </div>
    <!-- end auth-fluid-form-box-->
</div>
<!-- end auth-fluid-->

</div>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logez-vous\resources\views/landlord/apartments/create.blade.php ENDPATH**/ ?>