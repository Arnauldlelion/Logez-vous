@extends('layouts.app') <!-- Assuming you have a layout file -->

@section('content')
<div class="container mb-5" style="margin-top:8rem">
    <div class="shadow-lg bg-white p-3 p-lg-5">
<!-- recent-properties.blade.php -->
<h1>Recently Created Properties</h1>

@foreach ($properties as $property)
    <div>
        <img src="{{ asset($property->image) }}" alt="Property Image">
        <h2>{{ $property->town }}</h2>
        <p>Quarter: {{ $property->quarter }}</p>
        <p>Monthly Price: {{ $property->monthly_price }}</p>
        <p>Size: {{ $property->size }}</p>
        <p>Pieces: {{ $property->pieces }}</p>
        <p>Description: {{ $property->description }}</p>
        <p>Furnished: {{ $property->furnished ? 'Yes' : 'No' }}</p>
        <p>Floor: {{ $property->floor }}</p>
    </div>
@endforeach
</div>
</div>
@endsection