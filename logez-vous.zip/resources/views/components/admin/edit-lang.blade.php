<div class="mb-3 text-right">
    <div class="edit-lang-options">
        <a href="{{ $route }}?lang=en"
           class="{{ $lang == 'en' ? 'active' : '' }}">Edit in English</a>
        <a href="{{ $route }}?lang=fr"
           class="{{ $lang == 'fr' ? 'active' : '' }}">Edit in French</a>
    </div>
</div>