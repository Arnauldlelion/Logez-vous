<div class="modal fade video-modal" id="video-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-body">
                <div class="text-end mb-3">
                    <button type="button" data-bs-dismiss="modal" class="modal-close">x</button>
                </div>
                <div class="ratio ratio-16x9">
                    <iframe src="https://www.youtube.com/embed/XKAkgdu5ZUc" title="YouTube video"
                        allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
