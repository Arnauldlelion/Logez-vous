<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Property;
use App\Models\Image;

class PropertiesController extends Controller
{
    public function properties()
    {
        $properties = Property::all();
        return view('properties', compact('properties'));
    }

    public function create()
    {
        return view('create-property');
    }
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
            'town' => 'required',
            'quarter' => 'required',
            'monthly_price' => 'required|numeric',
            'size' => 'required|numeric',
            'pieces' => 'required|numeric',
            'description' => 'required',
            'furnished' => 'boolean', // Added field: boolean validation
            'floor' => 'required|in:ground,first,second,third,fourth,fifth', // Added field: enumeration validation
        ]);

        $imagePath = $request->file('image')->store('images');

        $property = new Property();
        $property->image = $imagePath;
        $property->town = $validatedData['town'];
        $property->quarter = $validatedData['quarter'];
        $property->monthly_price = $validatedData['monthly_price'];
        $property->size = $validatedData['size'];
        $property->pieces = $validatedData['pieces'];
        $property->description = 'Property description'; // Add a default description or retrieve it from the form input
        $property->furnished = $validatedData['furnished']; // Add the 'furnished' field
        $property->floor = $validatedData['floor']; // Add the 'floor' field
        // Set other property attributes accordingly

        $property->save();

        return redirect()->route('properties.recent')->with('success', 'New property created successfully.');
    }

    public function recent()
    {
        $properties = Property::latest()->take(10)->get(); // Retrieve the 10 most recent properties
    
        return view('recent-properties', ['properties' => $properties]);
    }
    


}
    
